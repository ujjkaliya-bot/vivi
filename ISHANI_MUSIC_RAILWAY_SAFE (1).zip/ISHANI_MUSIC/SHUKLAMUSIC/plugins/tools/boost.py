# -----------------------------------------------
# 🔸 StrangerMusic Project
# 🔹 Developed & Maintained by: Shashank Shukla (https://github.com/itzshukla)
# 📅 Copyright © 2025 – All Rights Reserved
#
# 📖 License:
# This source code is open for educational and non-commercial use ONLY.
# You are required to retain this credit in all copies or substantial portions of this file.
# Commercial use, redistribution, or removal of this notice is strictly prohibited
# without prior written permission from the author.
#
# ❤️ Made with dedication and love by ItzShukla
# -----------------------------------------------

import re
from os import getenv
from dotenv import load_dotenv
from pyrogram import filters, Client
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
from SHUKLAMUSIC import app
from SHUKLAMUSIC.utils.database import booster

load_dotenv()

OWNERS = "7361624774"


@app.on_message(
    filters.command("boost") & filters.private & filters.user(int(OWNERS))
)
async def show_config(client: Client, message: Message):
    await message.reply_text(
        "<b>Ishani Music</b>\n\n"
        "Configuration is stored securely in Railway Variables. "
        "Sensitive credentials are never displayed in chat."
    )
