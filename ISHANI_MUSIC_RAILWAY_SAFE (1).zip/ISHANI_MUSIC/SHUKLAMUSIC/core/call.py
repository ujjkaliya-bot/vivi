# -----------------------------------------------
# 🔸 StrangerMusic Project
# 🔹 Developed & Maintained by: Shashank Shukla
# 📅 Copyright © 2022 – All Rights Reserved
# -----------------------------------------------

import asyncio
import os
from datetime import datetime, timedelta
from typing import Union

from ntgcalls import ConnectionNotFound, TelegramServerError
from pyrogram import Client
from pyrogram.types import InlineKeyboardMarkup
from pytgcalls import PyTgCalls, exceptions, types
from pytgcalls.pytgcalls_session import PyTgCallsSession

import config
from SHUKLAMUSIC import LOGGER, YouTube, app
from SHUKLAMUSIC.misc import db
from SHUKLAMUSIC.utils.database import (
    add_active_chat,
    add_active_video_chat,
    get_lang,
    get_loop,
    group_assistant,
    is_autoend,
    music_on,
    remove_active_chat,
    remove_active_video_chat,
    set_loop,
    get_autoplay,
    add_autoplay_history,
    get_autoplay_history,
    clear_autoplay_history,
)
from SHUKLAMUSIC.utils.exceptions import AssistantErr
from SHUKLAMUSIC.utils.formatters import (
    check_duration,
    seconds_to_min,
    speed_converter,
)
from SHUKLAMUSIC.utils.inline.play import stream_markup
from SHUKLAMUSIC.utils.stream.autoclear import auto_clean
from SHUKLAMUSIC.utils.stream.queue import put_queue
from SHUKLAMUSIC.utils.thumbnails import get_thumb
from SHUKLAMUSIC.plugins.play.stream import send_queue_empty_msg
from strings import get_string

autoend = {}
counter = {}


async def _clear_(chat_id: int):
    db[chat_id] = []
    await remove_active_video_chat(chat_id)
    await remove_active_chat(chat_id)


class Call(PyTgCalls):
    def __init__(self):
        PyTgCallsSession.notice_displayed = True

        self.userbot1 = Client(
            name="SHUKLAAss1",
            api_id=config.API_ID,
            api_hash=config.API_HASH,
            session_string=str(config.STRING1),
        )
        self.one = PyTgCalls(self.userbot1, cache_duration=100)

        self.userbot2 = Client(
            name="SHUKLAAss2",
            api_id=config.API_ID,
            api_hash=config.API_HASH,
            session_string=str(config.STRING2),
        )
        self.two = PyTgCalls(self.userbot2, cache_duration=100)

        self.userbot3 = Client(
            name="SHUKLAAss3",
            api_id=config.API_ID,
            api_hash=config.API_HASH,
            session_string=str(config.STRING3),
        )
        self.three = PyTgCalls(self.userbot3, cache_duration=100)

        self.userbot4 = Client(
            name="SHUKLAAss4",
            api_id=config.API_ID,
            api_hash=config.API_HASH,
            session_string=str(config.STRING4),
        )
        self.four = PyTgCalls(self.userbot4, cache_duration=100)

        self.userbot5 = Client(
            name="SHUKLAAss5",
            api_id=config.API_ID,
            api_hash=config.API_HASH,
            session_string=str(config.STRING5),
        )
        self.five = PyTgCalls(self.userbot5, cache_duration=100)

    def _build_stream(
        self,
        source: str,
        video: bool,
        ffmpeg: str | None = None,
    ) -> types.MediaStream:
        base_flags = "-threads 0"
        combined = f"{base_flags} {ffmpeg}" if ffmpeg else base_flags

        return types.MediaStream(
            media_path=source,
            audio_parameters=types.AudioQuality.MEDIUM,
            video_parameters=types.VideoQuality.HD_720p,
            audio_flags=types.MediaStream.Flags.REQUIRED,
            video_flags=(
                types.MediaStream.Flags.AUTO_DETECT
                if video
                else types.MediaStream.Flags.IGNORE
            ),
            ffmpeg_parameters=combined,
        )

    async def _play_on_assistant(
        self,
        client: PyTgCalls,
        chat_id: int,
        stream: types.MediaStream,
    ):
        await client.play(
            chat_id=chat_id,
            stream=stream,
            config=types.GroupCallConfig(auto_start=False),
        )

    async def pause_stream(self, chat_id: int):
        assistant = await group_assistant(self, chat_id)
        await assistant.pause(chat_id)

    async def resume_stream(self, chat_id: int):
        assistant = await group_assistant(self, chat_id)
        await assistant.resume(chat_id)

    async def stop_stream(self, chat_id: int):
        assistant = await group_assistant(self, chat_id)
        try:
            await _clear_(chat_id)
            await assistant.leave_call(chat_id, close=False)
        except Exception:
            pass

    async def stop_stream_force(self, chat_id: int):
        for string, client in [
            (config.STRING1, self.one),
            (config.STRING2, self.two),
            (config.STRING3, self.three),
            (config.STRING4, self.four),
            (config.STRING5, self.five),
        ]:
            if not string:
                continue
            try:
                await client.leave_call(chat_id, close=False)
            except Exception:
                pass

        try:
            await _clear_(chat_id)
        except Exception:
            pass

    async def speedup_stream(self, chat_id: int, file_path, speed, playing):
        assistant = await group_assistant(self, chat_id)

        if str(speed) != "1.0":
            base = os.path.basename(file_path)
            chatdir = os.path.join(os.getcwd(), "playback", str(speed))
            os.makedirs(chatdir, exist_ok=True)
            out = os.path.join(chatdir, base)

            if not os.path.isfile(out):
                if str(speed) == "0.5":
                    vs = 2.0
                elif str(speed) == "0.75":
                    vs = 1.35
                elif str(speed) == "1.5":
                    vs = 0.68
                elif str(speed) == "2.0":
                    vs = 0.5
                else:
                    vs = 1.0

                proc = await asyncio.create_subprocess_shell(
                    f"ffmpeg -i {file_path} "
                    f"-filter:v setpts={vs}*PTS "
                    f"-filter:a atempo={speed} {out}",
                    stdin=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                await proc.communicate()
        else:
            out = file_path

        dur = await asyncio.get_event_loop().run_in_executor(
            None,
            check_duration,
            out,
        )
        dur = int(dur)

        played, con_seconds = speed_converter(
            playing[0]["played"],
            speed,
        )

        duration = seconds_to_min(dur)
        ffmpeg = f"-ss {played} -to {duration}"
        video_mode = playing[0]["streamtype"] == "video"

        stream = self._build_stream(
            out,
            video=video_mode,
            ffmpeg=ffmpeg,
        )

        if str(db[chat_id][0]["file"]) != str(file_path):
            raise AssistantErr("Umm")

        await self._play_on_assistant(
            assistant,
            chat_id,
            stream,
        )

        exis = playing[0].get("old_dur")

        if not exis:
            db[chat_id][0]["old_dur"] = db[chat_id][0]["dur"]
            db[chat_id][0]["old_second"] = db[chat_id][0]["seconds"]

        db[chat_id][0]["played"] = con_seconds
        db[chat_id][0]["dur"] = duration
        db[chat_id][0]["seconds"] = dur
        db[chat_id][0]["speed_path"] = out
        db[chat_id][0]["speed"] = speed

    async def force_stop_stream(self, chat_id: int):
        assistant = await group_assistant(self, chat_id)

        try:
            check = db.get(chat_id)
            check.pop(0)
        except Exception:
            pass

        await remove_active_video_chat(chat_id)
        await remove_active_chat(chat_id)

        try:
            await assistant.leave_call(chat_id, close=False)
        except Exception:
            pass

    async def skip_stream(
        self,
        chat_id: int,
        link: str,
        video: Union[bool, str] = None,
        image: Union[bool, str] = None,
    ):
        assistant = await group_assistant(self, chat_id)

        stream = self._build_stream(
            link,
            video=bool(video),
        )

        await self._play_on_assistant(
            assistant,
            chat_id,
            stream,
        )

    async def seek_stream(
        self,
        chat_id,
        file_path,
        to_seek,
        duration,
        mode,
    ):
        assistant = await group_assistant(self, chat_id)

        ffmpeg = f"-ss {to_seek} -to {duration}"
        video_mode = mode == "video"

        stream = self._build_stream(
            file_path,
            video=video_mode,
            ffmpeg=ffmpeg,
        )

        await self._play_on_assistant(
            assistant,
            chat_id,
            stream,
        )

    async def stream_call(self, link):
        assistant = await group_assistant(
            self,
            config.LOG_GROUP_ID,
        )

        stream = self._build_stream(
            link,
            video=True,
        )

        await self._play_on_assistant(
            assistant,
            config.LOG_GROUP_ID,
            stream,
        )

        await asyncio.sleep(0.2)

        try:
            await assistant.leave_call(
                config.LOG_GROUP_ID,
                close=False,
            )
        except Exception:
            pass

    async def join_call(
        self,
        chat_id: int,
        original_chat_id: int,
        link,
        video: Union[bool, str] = None,
        image: Union[bool, str] = None,
    ):
        assistant = await group_assistant(
            self,
            chat_id,
        )

        language = await get_lang(chat_id)
        _ = get_string(language)

        userbot = (
            getattr(assistant, "app", None)
            or getattr(assistant, "_app", None)
            or assistant
        )

        ASSISTANT_ID = 6478513215

        try:
            await userbot.get_chat_member(
                chat_id,
                "me",
            )
        except Exception:
            try:
                await app.add_chat_members(
                    chat_id,
                    ASSISTANT_ID,
                )
                await asyncio.sleep(0.5)
            except Exception:
                pass

            try:
                await app.approve_chat_join_request(
                    chat_id,
                    ASSISTANT_ID,
                )
                await asyncio.sleep(0.3)
            except Exception:
                pass

            try:
                await userbot.get_chat_member(
                    chat_id,
                    "me",
                )
            except Exception:
                try:
                    inv_obj = await app.create_chat_invite_link(
                        chat_id
                    )
                    invitelink = inv_obj.invite_link

                    if invitelink:
                        await userbot.join_chat(invitelink)
                        await asyncio.sleep(0.5)

                        try:
                            await app.approve_chat_join_request(
                                chat_id,
                                ASSISTANT_ID,
                            )
                        except Exception:
                            pass
                except Exception:
                    pass

        stream = self._build_stream(
            link,
            video=bool(video),
        )

        try:
            await self._play_on_assistant(
                assistant,
                chat_id,
                stream,
            )
        except exceptions.NoActiveGroupCall:
            raise AssistantErr(_["call_8"])
        except exceptions.NoAudioSourceFound:
            raise AssistantErr(_["call_10"])
        except (
            ConnectionNotFound,
            TelegramServerError,
        ):
            raise AssistantErr(_["call_10"])
        except Exception:
            raise AssistantErr(_["call_10"])

        await add_active_chat(chat_id)
        await music_on(chat_id)

        if video:
            await add_active_video_chat(chat_id)

        if await is_autoend():
            counter[chat_id] = {}

            users = len(
                await assistant.get_participants(chat_id)
            )

            if users == 1:
                autoend[chat_id] = (
                    datetime.now()
                    + timedelta(minutes=1)
                )

    async def change_stream(
        self,
        client: PyTgCalls,
        chat_id: int,
    ):
        check = db.get(chat_id)
        popped = None
        loop = await get_loop(chat_id)

        try:
            if loop == 0:
                popped = check.pop(0)
            else:
                loop -= 1
                await set_loop(chat_id, loop)

            await auto_clean(popped)

            if not check:
                # ---- AUTOPLAY: queue khatam ho gayi ----
                seed_vidid = popped.get("vidid") if popped else None
                is_youtube_seed = bool(
                    seed_vidid
                    and seed_vidid not in ("telegram", "soundcloud")
                    and len(str(seed_vidid)) <= 20
                )

                if is_youtube_seed and await get_autoplay(chat_id):
                    found = None
                    try:
                        history = await get_autoplay_history(chat_id)
                        found = await YouTube.related(seed_vidid, history)
                    except Exception:
                        found = None

                    if found:
                        rel_vidid, rel_title = found
                        file_path = None
                        try:
                            file_path, direct = await YouTube.download(
                                rel_vidid, None, videoid=True,
                            )
                        except Exception:
                            file_path = None

                        rel_duration_min = "Unknown"
                        rel_thumb = None
                        try:
                            (
                                _det_title,
                                rel_duration_min,
                                _,
                                rel_thumb,
                                _,
                            ) = await YouTube.details(
                                rel_vidid, videoid=True,
                            )
                        except Exception:
                            rel_duration_min = "Unknown"
                            rel_thumb = None

                        if file_path:
                            original_chat_id = popped.get("chat_id", chat_id)
                            language = await get_lang(chat_id)
                            _ = get_string(language)

                            db[chat_id] = []
                            await put_queue(
                                chat_id,
                                original_chat_id,
                                file_path if direct else f"vid_{rel_vidid}",
                                rel_title,
                                rel_duration_min,
                                "🎧 Autoplay",
                                rel_vidid,
                                0,
                                "audio",
                            )

                            stream = self._build_stream(file_path, video=False)
                            try:
                                await self._play_on_assistant(
                                    client, chat_id, stream
                                )
                            except Exception:
                                await clear_autoplay_history(chat_id)
                                await _clear_(chat_id)
                                return await client.leave_call(
                                    chat_id, close=False
                                )

                            await add_autoplay_history(chat_id, rel_vidid)

                            button = stream_markup(_, chat_id)
                            img = await get_thumb(
                                rel_vidid,
                                fallback_title=rel_title,
                                fallback_thumbnail=rel_thumb,
                            )

                            run = await app.send_photo(
                                original_chat_id,
                                photo=img,
                                has_spoiler=True,
                                caption=_["stream_1"].format(
                                    f"https://t.me/{app.username}?start=info_{rel_vidid}",
                                    rel_title[:23],
                                    rel_duration_min,
                                    "🎧 Autoplay",
                                ),
                                reply_markup=InlineKeyboardMarkup(button),
                            )

                            db[chat_id][0]["mystic"] = run
                            db[chat_id][0]["markup"] = "stream"
                            return

                # Autoplay band hai, ya related gaana nahi mila -> normal exit
                await clear_autoplay_history(chat_id)
                await _clear_(chat_id)
                return await client.leave_call(
                    chat_id,
                    close=False,
                )

        except Exception:
            try:
                await _clear_(chat_id)
                return await client.leave_call(
                    chat_id,
                    close=False,
                )
            except Exception:
                return

        queued = check[0]["file"]

        language = await get_lang(chat_id)
        _ = get_string(language)

        title = check[0]["title"].title()
        user = check[0]["by"]
        original_chat_id = check[0]["chat_id"]
        streamtype = check[0]["streamtype"]
        videoid = check[0]["vidid"]

        db[chat_id][0]["played"] = 0

        exis = check[0].get("old_dur")

        if exis:
            db[chat_id][0]["dur"] = exis
            db[chat_id][0]["seconds"] = check[0]["old_second"]
            db[chat_id][0]["speed_path"] = None
            db[chat_id][0]["speed"] = 1.0

        video = str(streamtype) == "video"

        # LIVE
        if "live_" in queued:
            n, link = await YouTube.video(
                videoid,
                True,
            )

            if n == 0:
                return await app.send_message(
                    original_chat_id,
                    text=_["call_6"],
                )

            stream = self._build_stream(
                link,
                video=video,
            )

            try:
                await self._play_on_assistant(
                    client,
                    chat_id,
                    stream,
                )
            except Exception:
                return await app.send_message(
                    original_chat_id,
                    text=_["call_6"],
                )

            button = stream_markup(_, chat_id)

            run = await app.send_message(
                chat_id=original_chat_id,
                text=_["stream_1"].format(
                    f"https://t.me/{app.username}?start=info_{videoid}",
                    title[:23],
                    check[0]["dur"],
                    user,
                ),
                reply_markup=InlineKeyboardMarkup(button),
            )

            db[chat_id][0]["mystic"] = run
            db[chat_id][0]["markup"] = "tg"

        # YOUTUBE VIDEO
        elif "vid_" in queued:
            mystic = await app.send_message(
                original_chat_id,
                _["call_7"],
            )

            try:
                file_path, direct = await YouTube.download(
                    videoid,
                    mystic,
                    videoid=True,
                    video=video,
                )
            except Exception:
                return await mystic.edit_text(
                    _["call_6"]
                )

            stream = self._build_stream(
                file_path,
                video=video,
            )

            try:
                await self._play_on_assistant(
                    client,
                    chat_id,
                    stream,
                )
            except Exception:
                return await app.send_message(
                    original_chat_id,
                    text=_["call_6"],
                )

            button = stream_markup(_, chat_id)

            await mystic.delete()

            caption = _["stream_1"].format(
                f"https://t.me/{app.username}?start=info_{videoid}",
                title[:23],
                check[0]["dur"],
                user,
            )

            try:
                img = await get_thumb(
                    videoid,
                    fallback_title=title,
                    fallback_thumbnail=f"https://i.ytimg.com/vi/{videoid}/hqdefault.jpg",
                )
                run = await app.send_photo(
                    original_chat_id,
                    photo=img,
                    has_spoiler=True,
                    caption=caption,
                    reply_markup=InlineKeyboardMarkup(button),
                )
            except Exception:
                run = await app.send_message(
                    chat_id=original_chat_id,
                    text=caption,
                    reply_markup=InlineKeyboardMarkup(button),
                )

            db[chat_id][0]["mystic"] = run
            db[chat_id][0]["markup"] = "stream"

        # INDEX
        elif "index_" in queued:
            stream = self._build_stream(
                videoid,
                video=video,
            )

            try:
                await self._play_on_assistant(
                    client,
                    chat_id,
                    stream,
                )
            except Exception:
                return await app.send_message(
                    original_chat_id,
                    text=_["call_6"],
                )

            button = stream_markup(_, chat_id)

            run = await app.send_message(
                chat_id=original_chat_id,
                text=_["stream_2"].format(user),
                reply_markup=InlineKeyboardMarkup(button),
            )

            db[chat_id][0]["mystic"] = run
            db[chat_id][0]["markup"] = "tg"

        # TELEGRAM / SOUNDCLOUD / YOUTUBE
        else:
            stream = self._build_stream(
                queued,
                video=video,
            )

            try:
                await self._play_on_assistant(
                    client,
                    chat_id,
                    stream,
                )
            except Exception:
                return await app.send_message(
                    original_chat_id,
                    text=_["call_6"],
                )

            button = stream_markup(_, chat_id)

            # TELEGRAM
            if videoid == "telegram":
                run = await app.send_message(
                    chat_id=original_chat_id,
                    text=_["stream_1"].format(
                        config.SUPPORT_GROUP,
                        title[:23],
                        check[0]["dur"],
                        user,
                    ),
                    reply_markup=InlineKeyboardMarkup(button),
                )

                db[chat_id][0]["mystic"] = run
                db[chat_id][0]["markup"] = "tg"

            # SOUNDCLOUD
            elif videoid == "soundcloud":
                run = await app.send_message(
                    chat_id=original_chat_id,
                    text=_["stream_1"].format(
                        config.SUPPORT_GROUP,
                        title[:23],
                        check[0]["dur"],
                        user,
                    ),
                    reply_markup=InlineKeyboardMarkup(button),
                )

                db[chat_id][0]["mystic"] = run
                db[chat_id][0]["markup"] = "tg"

            # YOUTUBE
            else:
                caption = _["stream_1"].format(
                    f"https://t.me/{app.username}?start=info_{videoid}",
                    title[:23],
                    check[0]["dur"],
                    user,
                )

                try:
                    img = await get_thumb(
                    videoid,
                    fallback_title=title,
                    fallback_thumbnail=f"https://i.ytimg.com/vi/{videoid}/hqdefault.jpg",
                )
                    run = await app.send_photo(
                        original_chat_id,
                        photo=img,
                        has_spoiler=True,
                        caption=caption,
                        reply_markup=InlineKeyboardMarkup(button),
                    )
                except Exception:
                    run = await app.send_message(
                        chat_id=original_chat_id,
                        text=caption,
                        reply_markup=InlineKeyboardMarkup(button),
                    )

                db[chat_id][0]["mystic"] = run
                db[chat_id][0]["markup"] = "stream"

    async def ping(self):
        pings = []

        if config.STRING1:
            pings.append(self.one.ping)
        if config.STRING2:
            pings.append(self.two.ping)
        if config.STRING3:
            pings.append(self.three.ping)
        if config.STRING4:
            pings.append(self.four.ping)
        if config.STRING5:
            pings.append(self.five.ping)

        return (
            str(round(sum(pings) / len(pings), 3))
            if pings
            else "0"
        )

    async def start(self):
        LOGGER(__name__).info(
            "Starting PyTgCalls Client...\n"
        )

        if config.STRING1:
            await self.one.start()

        if config.STRING2:
            await self.two.start()

        if config.STRING3:
            await self.three.start()

        if config.STRING4:
            await self.four.start()

        if config.STRING5:
            await self.five.start()

    async def decorators(self):
        for string, client in [
            (config.STRING1, self.one),
            (config.STRING2, self.two),
            (config.STRING3, self.three),
            (config.STRING4, self.four),
            (config.STRING5, self.five),
        ]:
            if not string:
                continue

            @client.on_update()
            async def _update_handler(
                _,
                update: types.Update,
                _client=client,
            ):
                if isinstance(
                    update,
                    types.StreamEnded,
                ):
                    if (
                        update.stream_type
                        == types.StreamEnded.Type.AUDIO
                    ):
                        await self.change_stream(
                            _client,
                            update.chat_id,
                        )

                elif isinstance(
                    update,
                    types.ChatUpdate,
                ):
                    if update.status in [
                        types.ChatUpdate.Status.KICKED,
                        types.ChatUpdate.Status.LEFT_GROUP,
                        types.ChatUpdate.Status.CLOSED_VOICE_CHAT,
                    ]:
                        await self.stop_stream(
                            update.chat_id
                        )


SHUKLA = Call()
